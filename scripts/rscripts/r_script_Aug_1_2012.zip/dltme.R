type <- comb.case
pdf(f.nm.res.pdf )
for(i in 1:length(ix)){ # go over datatypes
	d.type <- ix[i]
	for(k in 1:length(tfs)){ # go over tfs
		tf <- tfs[k]
		x <- AUCPR
		ylim <- c(0,0.4)
		xlim <- c(1,length(ix))
		if(k==1 & i==1){
			plot(y=x[[tf]][ix][1],x=k,pch=pchs[k],main=paste(sep="---",type,c.tp),xlim=xlim,ylim=ylim,col=cls[k],
			xlab="Datatype",ylab="Area Under Curve PR",cex=1.5,type="n",axes = FALSE)
			axis(2,cex.axis=2)
			text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)
		}
		if(k==1){
			barplot(AUCPR.5.way[[d.type]],space=i-0.5,width=1,col=cls.bars[i],add=T,axes = FALSE,names.arg="")
			# rnd.val <- max(r.vec.sum.pr[d.type][d.type],r.vec.single.pr[d.type][d.type])
			# barplot(rnd.val,space=i-0.5,width=1,col="gray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.sum.pr[d.type][d.type],space=i*2-1,width=0.5,col="darkgray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.single.pr[d.type][d.type],space=i*2,width=0.5,col="lightgray",add=T,axes = FALSE,names.arg="")				
			barplot(r.vec.sum.pr[d.type][d.type],space=i*5-1,width=0.2,col="darkgray",add=T,axes = FALSE,names.arg="")
			barplot(r.vec.single.pr[d.type][d.type],space=i*5,width=0.2,col="lightgray",add=T,axes = FALSE,names.arg="")				
		}
		if(tf=="RORC"){
			points(y=x[[tf]][d.type],x=i,pch=rorc.pch,cex=1.5,col=cls[k])			
		} else {
			points(y=x[[tf]][d.type],x=i,pch=pchs[k],cex=1.2,col=cls[k])			
		}
	}
}
legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(pchs,3,0)))

# legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(rep(pch,length(tfs)),8)))
for(i in 1:length(ix)){ # go over datatypes
	d.type <- ix[i]
	for(k in 1:length(tfs)){ # go over tfs
		tf <- tfs[k]
		x <- AUCROC
		ylim <- c(0.5,1)
		xlim <- c(1,length(ix))
		if(k==1 & i==1){
			plot(y=x[[tf]][ix][1],x=k,pch=pchs[k],main=paste(sep="---",type,c.tp),xlim=xlim,ylim=ylim,col=cls[k],
			xlab="Datatype",ylab="Area Under Curve PR",cex=1.5,type="n",axes = FALSE)
			axis(2,cex.axis=2)
			text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)
		}
		if(k==1){
			barplot(AUCROC.5.way[[d.type]],space=i-0.5,width=1,col=cls.bars[i],add=T,axes = FALSE)
			# rnd.val <- max(r.vec.sum.roc[d.type][d.type],r.vec.single.roc[d.type][d.type])
			# barplot(rnd.val,space=i-0.5,width=1,col="gray",add=T,axes = FALSE,names.arg="")
			barplot(r.vec.sum.roc[d.type][d.type],space=i*5-1,width=0.2,col="darkgray",add=T,axes = FALSE,names.arg="")
			barplot(r.vec.single.roc[d.type][d.type],space=i*5,width=0.2,col="lightgray",add=T,axes = FALSE,names.arg="")				
		}
		if(tf=="RORC"){
			points(y=x[[tf]][d.type],x=i,pch=rorc.pch,cex=1.5,col=cls[k])			
		} else {
			points(y=x[[tf]][d.type],x=i,pch=pchs[k],cex=1.2,col=cls[k])			
		}
	}
}
text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)

# legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(pchs,3,0)))
dev.off()
