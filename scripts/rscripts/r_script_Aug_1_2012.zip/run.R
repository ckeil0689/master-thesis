# simple wrapper R script to deal with default R naming conventions
# 
# Author: crispy
###############################################################################

source("scripts/main.R")
