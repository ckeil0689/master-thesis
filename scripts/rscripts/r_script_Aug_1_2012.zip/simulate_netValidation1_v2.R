##  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.
## /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ / / \ \ / / \ \
##`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   ' '
## Apr 2011 Th17 project (MCZ,tlCLR,Inferelator)
## Bonneau lab - "Aviv Madar" <am2654@nyu.edu>, 
## NYU - Center for Genomics and Systems Biology
##  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.
## /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ / / \ \ / / \ \
##`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   ' '

# R code to create quality control plots for entire network pipeline
library(caTools) # to use integration under curve (Trapezoid Rule Numerical Integration)
source("r_scripts/th17/used_for_paper/simulations_util.R")


path.input.gold.standard <- "input/th17/used_for_paper/gold_standard_lists/"
path.output <- paste(sep="","results/validation/",date.is,"/")
system(paste(sep="","mkdir ", path.output))			
path.input.sam <- "input/th17/used_for_paper/"
path.input.combined <- paste(sep="","results/combinedAnalysis/",date.combine.data.run,"/")
# make output directory
if(any("P300" %in% tfs)){
	num.tfs.tmp <- num.tfs-1
} else {
	num.tfs.tmp <- num.tfs
}
if(filter.by.sam==TRUE){
	add.str <- paste(sep="","_cut_prcnt_",prcnt.chng.cut,"_num_tfs_",num.tfs.tmp,"_sam_",z.abs.cut,"_deseq_cut_",deseq.pval.cut)
} else {
	add.str <- paste(sep="","_cut_prcnt_",prcnt.chng.cut,"_num_tfs_",num.tfs.tmp,"_sam_",0,"_deseq_cut_",deseq.pval.cut)
}
infl.nm <- paste(path.input.combined,"results_combine_data_exprsn",add.str,".Rdata",sep="")
# load input files
load(infl.nm)
keepers <- colnames(res[[1]][[1]][[1]])[1:16]
## gold standard files
th17.gns.f.nm <- paste(sep="",path.input.gold.standard,fl.nm.gs)
gs.gns <- read.delim(sep="\t",header=T,th17.gns.f.nm, as.is=T)
ix <- which(gs.gns$distance<cut.dist)
gs.gns <- toupper(gs.gns[,"gene_id"])[ix]

########################################
# for efficiency of simulation code 
# keep only data used in res
########################################
tp <- comb.case # e.g. tp = activation
c.tp <- c.type.all.in.one.plot # e.g. chip comes for Th17
res.tmp <- list() # create a reduced list of res for only conditions we want to look at
for(j in 1:length(tfs)){ # go over tfs
	tf <- tfs[j]
	res.tmp[[tf]] <- res[[tp]][[tf]][[c.tp]]
}
res.orig <- res.tmp
rm(res.tmp)
########################################
# if dealing with repression
# make sam scores opposite sign so we can plot performance of sam if we wish
# otherwise absolute sign
########################################
if(tp=="repression"){
	res.orig[,"SAM"] <- -1*res.orig[,"SAM"]
} else if (tp=="absolute"){
	res.orig[,"SAM"] <- abs(res.orig[,"SAM"])
}
########################################
# to make simulations more realistic
# limit R,I datasets to only consider
# diff expressed genes 
# as this is what we have done with 
# original data
########################################
m <- res.orig[[1]] # a sample matrix of results
# this are the allowed genes for Chip (all genes)
ix.chip <- 1:nrow(m)
# this are the allowed genes for KO (genes with rpkm > 3 in either th17 or th0) this is more conservative than what we acutally did (or >3 in either ko or wt)
# ix.ko <- which( (abs(m[,"th17_rpkm"])>min.rpkm) | (abs(m[,"th0_rpkm"])>min.rpkm) ) 
ix.ko <- 1:nrow(m)
# this are the allowed genes for Immgen and RNAseq (genes with absolute sam th17 vs. th0 bigger than 2.5)
ix.immgen <- which(abs(m[,"SAM"])>z.abs.cut)
ix.rnaseq <- which(abs(m[,"SAM"])>z.abs.cut)
########################################
# start running permuations
########################################
# here we will keep auc's (1'st auc stored is for real net, the rest are permutations)
aucPR.single.tf <- list()
aucROC.single.tf <- list()
aucPR.5way <- list()
aucROC.5way <- list()



for(p in 1:Np){
	# first permutation is real data other wise we permute data to get random aucPR/aucROC
	if(p>1){
		res <- list()
		for(j in 1:length(tfs)){ # go over tfs
			tf <- tfs[j]
			# permutations individucally for each core data type (K,C,R,I)
			ix.sample.chip <- sample(ix.chip)
			ix.sample.ko <- sample(ix.ko)
			ix.sample.immgen <- sample(ix.immgen)
			ix.sample.rnaseq <- sample(ix.rnaseq)
			res[[tf]] <- simulate.combine.data(res.orig[[tf]],
									ix.chip,ix.ko,ix.immgen,ix.rnaseq,
									ix.sample.chip,ix.sample.ko,ix.sample.immgen,ix.sample.rnaseq)
		}
	} else {
		res <- res.orig
	}
	########################################
	# sum scores over tfs
	########################################
	ix.add <- 1:15 # only add for K,C,R,I or combination (not for sam, deseq, etc)
	o.sum.list <- list() # here we store the summed scores over all tfs
	for(j in 1:length(tfs)){ # go over tfs
		tf <- tfs[j]
		if(j==1){ # if first tf start the summation
			o.sum.list <- res[[tf]]
		} else {
			o.sum.list[,ix.add] <- o.sum.list[,ix.add] + res[[tf]][,ix.add]
		}
	}
	########################################
	# convert summed scores into relative ranks for ploting
	########################################
	# convert combined scores for multiple tfs into relative ranks for ploting
	o.sum.rel.list <- list() # here we store the summed scores over all tfs
	# prepare list of matrices to store data for relative ranks
	gns <- rownames(o.sum.list)
	o.sum.rel.list <- matrix(0,nr=nrow(o.sum.list),nc=ncol(o.sum.list))
	colnames(o.sum.rel.list) <- colnames(o.sum.list)
	for(j in 1:ncol(o.sum.list)){
		o.sum.rel.list[,j] <- gns[order(o.sum.list[,j],decreasing=T)]
	}
	########################################
	# convert single TF scores into relative ranks for ploting
	########################################
	o.rel.list <- list() # here we store the relative scores for each tfs
	for(i in 1:length(tfs)){ # go over tfs
		tf <- tfs[i]	
		# prepare list of matrices to store data for relative ranks
		gns <- rownames(res[[tf]])
		o.rel.list[[tf]] <- matrix(0,nr=nrow(res[[tf]]),nc=ncol(res[[tf]]))
		colnames(o.rel.list[[tf]]) <- colnames(res[[tf]])
		for(j in 1:ncol(o.rel.list[[tf]])){
			o.rel.list[[tf]][,j] <- gns[order(res[[tf]][,j],decreasing=T)]
		}
	}

	########################################
	# calc aucPR/aucROC for summed scores
	########################################
	prec <- list()
	rec <- list()
	tpr <- list()
	fpr <- list()
	AUCPR <- list()
	AUCROC <- list()
	x.rel.nms <- o.sum.rel.list
	x.rel <- seq(from=0,to=1,length.out=dim(x.rel.nms)[1])
	gold.gns <-  gs.gns
	positive.rel.ranks <- list() # find what relative ranks gold std gns received
	for(j in 1:length(keepers)){
		positive.rel.ranks[[ keepers[j] ]] <- x.rel[which(x.rel.nms[,keepers[j]]%in%gs.gns)]
	}
	# calc precision vs. recal and roc curve
	for(i in 1:length(keepers)){
		x <- positive.rel.ranks[[ keepers[i] ]]
		neg.tot <- length(x.rel)-length(x)
		tp <- numeric(length(x)) # true positive so far (elem j)
		fp <- numeric(length(x)) # false positive so far, fp.j= total positive minus true positive so far 
		fn <-  numeric(length(x)) # true negative so far, tn.j= total so far minus positive so far
		tn <- numeric(length(x))	
		for(j in 1:length(positive.rel.ranks[[i]])){
			tp[j] <- j # true positive so far (elem j)
			fp[j] <- (which(x.rel==x[j])-j) # false positive so far, fp.j= total positive minus true positive so far 
			fn[j] <-  length(x) - j # true negative so far, tn.j= total so far minus positive so far
			tn[j] <- neg.tot-fp[j]
		}
		prec[[ keepers[i] ]] <- tp/(tp+fp)
		rec[[ keepers[i] ]] <- tp/(tp+fn)
		tpr[[ keepers[i] ]] <- c(tp/(tp+fn),1)
		fpr[[ keepers[i] ]] <- c(fp/(fp+tn),1)
		AUCPR[[ keepers[i] ]] <- trapz(x=rec[[ keepers[i] ]], 
												y=prec[[ keepers[i] ]])
		AUCROC[[ keepers[i] ]] <- trapz(x=fpr[[ keepers[i] ]], 
												y=tpr[[ keepers[i] ]])
	}
	# keep AUC values
	aucPR.5way[[p]] <- AUCPR
	aucROC.5way[[p]] <- AUCROC
	########################################
	# calc aucPR/aucROC for single TFs
	########################################
	prec <- list()
	rec <- list()
	tpr <- list()
	fpr <- list()
	AUCPR <- list()
	AUCROC <- list()
	for(k in 1:length(tfs)){ # go over tfs
		tf <- tfs[k]	
		x.rel.nms <- o.rel.list[[tf]]
		x.rel <- seq(from=0,to=1,length.out=dim(x.rel.nms)[1])
		gold.gns <- gs.gns

		positive.rel.ranks <- list() # find what relative ranks gold std gns received
		for(j in 1:length(keepers)){
			positive.rel.ranks[[ keepers[j] ]] <- x.rel[which(x.rel.nms[,keepers[j]]%in%gs.gns)]
		}	
		prec[[tf]] <- list()
		rec[[tf]] <- list()
		tpr[[tf]] <- list()
		fpr[[tf]] <- list()
		AUCPR[[tf]] <- list()
		AUCROC[[tf]] <- list()
		for(i in 1:length(keepers)){
			x <- positive.rel.ranks[[ keepers[i] ]]
			neg.tot <- length(x.rel)-length(x)
			# fpr[[ keepers[i] ]] <- numeric(length(positive.rel.ranks[[i]]))
			tp <- numeric(length(x)) # true positive so far (elem j)
			fp <- numeric(length(x)) # false positive so far, fp.j= total positive minus true positive so far 
			fn <-  numeric(length(x)) # true negative so far, tn.j= total so far minus positive so far
			tn <- numeric(length(x))	
			for(j in 1:length(positive.rel.ranks[[i]])){
				tp[j] <- j # true positive so far (elem j)
				fp[j] <- (which(x.rel==x[j])-j) # false positive so far, fp.j= total positive minus true positive so far 
				fn[j] <-  length(x) - j # true negative so far, tn.j= total so far minus positive so far
				tn[j] <- neg.tot-fp[j]
			}
			prec[[tf]][[ keepers[i] ]] <- tp/(tp+fp)
			rec[[tf]][[ keepers[i] ]] <- tp/(tp+fn)
			tpr[[tf]][[ keepers[i] ]] <- c(tp/(tp+fn),1)
			fpr[[tf]][[ keepers[i] ]] <- c(fp/(fp+tn),1)
			AUCPR[[tf]][[ keepers[i] ]] <- trapz(x=rec[[tf]][[ keepers[i] ]], 
													y=prec[[tf]][[ keepers[i] ]])
			AUCROC[[tf]][[ keepers[i] ]] <- trapz(x=fpr[[tf]][[ keepers[i] ]], 
													y=tpr[[tf]][[ keepers[i] ]])
		}
	}
	aucPR.single.tf[[p]] <- AUCPR
	aucROC.single.tf[[p]] <- AUCROC

}

# helper function to capitalize tfs name (only first letter is capped)
capwords <- function(s, strict = FALSE) {
    cap <- function(s) paste(toupper(substring(s,1,1)),
                  {s <- substring(s,2); if(strict) tolower(s) else s},
                             sep = "", collapse = " " )
    sapply(strsplit(s, split = " "), cap, USE.NAMES = !is.null(names(s)))
}


f.nm.res.pdf <- paste(sep="",path.output, "vldtn_perTF_AllInOne2_",comb.case,"_",
						c.type.all.in.one.plot,add.str,"_gs_data_",gs.list,"_",gold.stdrd.date,".pdf")
# cls <- c(rainbow(length(AUCPR)+1))[-2]

# colors for tfs: "BATF"  "MAF"   "IRF4"  "STAT3" "RORC"
cls <- c(colors()[566],#BATF="royalblue1"
		 colors()[642],#MAF=violetred1
		 colors()[496],#IRF4=olivedrab3
		 colors()[512],#STAT3=orchid4
		 colors()[566])#RORC=royalblue1
pchs <-	c(18,#BATF=diamond (full)
		 15,#MAF=square (full)
		 17,#IRF4=triangle (full)
		 16)#STAT3=circle full)
rorc.pch <- "-" #RORC=dodgerblue	
# colors for sum scores bar plots: 
cls.bars <- c(rep(colors()[616],4),#k,c,r,i=steelblue1
		 rep(colors()[652],6),#two ways=yellow
		 rep(colors()[136],5))#three-fourways=firebrick3
# ix <- c("I","R","K","C","KC","RI","CRI","KRI","KCR","KCI","KCRI") 
# ix <- colnames(res[[1]])[1:15]
# reorganize ix to make trends between comb levels clear
ix=c("I","R","C","K","CI","CR","KR","RI","KI","KC","CRI","KCR","KRI","KCI","KCRI")
  

# get real results
AUCPR <- aucPR.single.tf[[1]]
AUCROC <- aucROC.single.tf[[1]]
AUCPR.5.way <- aucPR.5way[[1]]
AUCROC.5.way <- aucROC.5way[[1]]
# get random results in a nice list for easy plotting
# first for single tf scores
aucpr.rand <- list()
aucroc.rand <- list()
for(k in 1:length(tfs)){
	tf <- tfs[k]
	aucpr.rand[[tf]] <- list()
	aucroc.rand[[tf]] <- list()	
	for(p in 2:Np){
		for(l in 1:length(ix)){
			combo <- ix[l]
			aucpr.rand[[tf]][[combo]] <- c(aucpr.rand[[tf]][[combo]],aucPR.single.tf[[p]][[tf]][[combo]])
			aucroc.rand[[tf]][[combo]] <- c(aucroc.rand[[tf]][[combo]],aucROC.single.tf[[p]][[tf]][[combo]])			
		}	
	}
}

# now for summed scores 5 way
aucpr.5way.rand <- list()
aucroc.5way.rand <- list()
for(p in 2:Np){
	for(l in 1:length(ix)){
		combo <- ix[l]
		aucpr.5way.rand[[combo]] <- c(aucpr.5way.rand[[combo]],aucPR.5way[[p]][[combo]])
		aucroc.5way.rand[[combo]] <- c(aucroc.5way.rand[[combo]],aucROC.5way[[p]][[combo]])			
	}
}
# use this for random (take all results for a data type, single or combined and show 95% score)
# r.vec.single.pr <- r.vec.single.roc <- numeric(length(ix))
# names(r.vec.single.pr) <- names(r.vec.single.roc) <- ix
# q <- 0.95 # this percentile to show as random our of all random runs for a data type
# for(i in 1:length(ix)){
# 	# q percentile
# 	d.type <- ix[i]
# 	for(k in 1:length(tfs)){
# 		r.vec.single.pr[d.type] <- quantile(aucpr.rand[[tf]][[d.type]],q)
# 		r.vec.single.roc[d.type] <- quantile(aucroc.rand[[tf]][[d.type]],q)
# 	}	
# }
# r.vec.sum.pr <- r.vec.sum.roc <- numeric(length(ix))
# names(r.vec.sum.pr) <- names(r.vec.sum.roc) <- ix
# for(i in 1:length(ix)){
# 	# q percentile
# 	d.type <- ix[i]
# 	r.vec.sum.pr[d.type] <- quantile(aucpr.5way.rand[[d.type]],q)
# 	r.vec.sum.roc[d.type] <- quantile(aucroc.5way.rand[[d.type]],q)
# }
r.vec.single.pr <- r.vec.single.roc <- matrix(0,nr=Np-1,nc=length(ix))
colnames(r.vec.single.pr) <- colnames(r.vec.single.roc) <- ix
for(i in 1:length(ix)){
	# q percentile
	d.type <- ix[i]
	for(k in 1:length(tfs)){
		r.vec.single.pr[,d.type] <- aucpr.rand[[tf]][[d.type]]
		r.vec.single.roc[,d.type] <- aucroc.rand[[tf]][[d.type]]
	}	
}
r.vec.sum.pr <- r.vec.sum.roc <- matrix(0,nr=Np-1,nc=length(ix))
colnames(r.vec.sum.pr) <- colnames(r.vec.sum.roc) <- ix
for(i in 1:length(ix)){
	# q percentile
	d.type <- ix[i]
	r.vec.sum.pr[,d.type] <- aucpr.5way.rand[[d.type]]
	r.vec.sum.roc[,d.type] <- aucroc.5way.rand[[d.type]]
}


type <- comb.case
pdf(f.nm.res.pdf )
for(i in 1:length(ix)){ # go over datatypes
	d.type <- ix[i]
	for(k in 1:length(tfs)){ # go over tfs
		tf <- tfs[k]
		x <- AUCPR
		ylim <- c(0,0.4)
		xlim <- c(1,length(ix))
		if(k==1 & i==1){
			plot(y=x[[tf]][ix][1],x=k,pch=pchs[k],main=paste(sep="---",type,c.tp),xlim=xlim,ylim=ylim,col=cls[k],
			xlab="Datatype",ylab="Area Under Curve PR",cex=1.5,type="n",axes = FALSE)
			axis(2,cex.axis=2)
			text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)
		}
		if(k==1){
			barplot(AUCPR.5.way[[d.type]],space=i-0.5,width=1,col=cls.bars[i],add=T,axes = FALSE,names.arg="")
			# rnd.val <- max(r.vec.sum.pr[d.type][d.type],r.vec.single.pr[d.type][d.type])
			# barplot(rnd.val,space=i-0.5,width=1,col="gray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.sum.pr[d.type][d.type],space=i*2-1,width=0.5,col="darkgray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.single.pr[d.type][d.type],space=i*2,width=0.5,col="lightgray",add=T,axes = FALSE,names.arg="")				
			boxplot(r.vec.sum.pr[,d.type],at=i-0.2,col="darkgray",add=T,axes = FALSE,names="",outline=F)
			boxplot(r.vec.single.pr[,d.type],at=i+0.2,col="darkgray",add=T,axes = FALSE,names="",outline=F)
			# barplot(r.vec.sum.pr[d.type][d.type],space=i*5-1,width=0.2,col="darkgray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.single.pr[d.type][d.type],space=i*5,width=0.2,col="lightgray",add=T,axes = FALSE,names.arg="")				
		}
		if(tf=="RORC"){
			points(y=x[[tf]][d.type],x=i,pch=rorc.pch,cex=1.5,col=cls[k])			
		} else {
			points(y=x[[tf]][d.type],x=i,pch=pchs[k],cex=1.2,col=cls[k])			
		}
	}
}
legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(pchs,3,0)))

# legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(rep(pch,length(tfs)),8)))
for(i in 1:length(ix)){ # go over datatypes
	d.type <- ix[i]
	for(k in 1:length(tfs)){ # go over tfs
		tf <- tfs[k]
		x <- AUCROC
		ylim <- c(0.5,1)
		xlim <- c(1,length(ix))
		if(k==1 & i==1){
			plot(y=x[[tf]][ix][1],x=k,pch=pchs[k],main=paste(sep="---",type,c.tp),xlim=xlim,ylim=ylim,col=cls[k],
			xlab="Datatype",ylab="Area Under Curve PR",cex=1.5,type="n",axes = FALSE)
			axis(2,cex.axis=2)
			text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)
		}
		if(k==1){
			barplot(AUCROC.5.way[[d.type]],space=i-0.5,width=1,col=cls.bars[i],add=T,axes = FALSE)
			# rnd.val <- max(r.vec.sum.roc[d.type][d.type],r.vec.single.roc[d.type][d.type])
			# barplot(rnd.val,space=i-0.5,width=1,col="gray",add=T,axes = FALSE,names.arg="")
			boxplot(r.vec.sum.roc[,d.type],at=i-0.2,col="darkgray",add=T,axes = FALSE,names="",outline=F)
			boxplot(r.vec.single.roc[,d.type],at=i+0.2,col="darkgray",add=T,axes = FALSE,names="",outline=F)
			# barplot(r.vec.sum.roc[d.type][d.type],space=i*5-1,width=0.2,col="darkgray",add=T,axes = FALSE,names.arg="")
			# barplot(r.vec.single.roc[d.type][d.type],space=i*5,width=0.2,col="lightgray",add=T,axes = FALSE,names.arg="")				
		}
		if(tf=="RORC"){
			points(y=x[[tf]][d.type],x=i,pch=rorc.pch,cex=1.5,col=cls[k])			
		} else {
			points(y=x[[tf]][d.type],x=i,pch=pchs[k],cex=1.2,col=cls[k])			
		}
	}
}
text(1:length(ix), par("usr")[3], labels = ix, srt = 90, adj = 1, xpd = TRUE,cex=1)

# legend("topleft",capwords(rev(c(tolower(tfs),"combined"))),col=rev(c(cls,"black")),pch=rev(c(pchs,3,0)))
dev.off()













