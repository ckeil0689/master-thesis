##  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.
## /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ / / \ \ / / \ \
##`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   ' '
## May 2011 th17
## Bonneau lab - "Aviv Madar" <am2654@nyu.edu>, 
## NYU - Center for Genomics and Systems Biology
##  .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.   .-.-.
## /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ /|/ \|\ / / \ \ / / \ \
##`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   `-`-'   ' '

## add 1 read psudo count
## take pvals instead of adjusted pvals


## helper function
plotDE <- function( res ) {
 plot( 
 res$baseMean, 
 res$log2FoldChange, 
 log="x", pch=20, cex=.1, 
 col = ifelse( res$padj < .1, "red", "black" ) ) 
}
########## read data ##########
library(DESeq)
cat("reading data\n")
# set paths
path.input <- "input/th17/used_for_paper/"
path.input.deseq <- "input/th17/used_for_paper/DEseq/"
path.input.counts <- paste(sep="","input/th17/used_for_paper/rawData/rnaseq_ht_counts_",date.htseq.data.compiled,"/")
# path.input.counts <- "/data/th17/data/htseq-count/"
path.input.fpkm <- "/data/th17/data/cufflinks/"
path.results <- paste(sep="","results/diff_expression/", date.is,"/")
system(paste(sep="","mkdir ",path.results))

# set file names
f.nm.info <- paste(sep="",path.input.deseq,"diffExpressionExptsPaired_",date.htseq.data.compiled,".txt") # which experiment to compare
f.nm.rpkm <- paste(sep="",path.input,"ranseqDatasetNoQuartNorm.RData") # which experiment to compare

## get count files (counting for each gene how many tags hit it)
count.files <- grep("counts",list.files(path.input.counts),value=T)

## read rpkm data
load(f.nm.rpkm)
d <- rnaseq.complete.matrix
expt.names <-colnames(d)
th17.wt.ix <- grep("th17_ss_48hr_.{1,6}_wt",colnames(d),value=T,perl=T)
th17.wt.ix <- c(th17.wt.ix,"SL1858_th17_ts_48hr#1")
th17.mean <- apply(d[,th17.wt.ix],1,mean)
th0.wt.ix <- grep("th0_ss_48hr_.{1,6}_wt",colnames(d),value=T,perl=T)
th0.wt.ix <- c(th0.wt.ix,"SL2673_th0_ts_48hr#1")
th0.mean <- apply(d[,th0.wt.ix],1,mean)
rpkm.mean <- pmax(th17.mean,th0.mean)
gns <- names(rpkm.mean)
# gns.low.rpkm <- names(rpkm.mean)[which(rpkm.mean < fpkm.cut)]


## read tab delim file with experiments we want to compare (format below):
## name	expts
## Th17.rorawt.rorcwt.vs.Th17.rorako.rorcko	SL5874_SL5878::SL5876_SL5880
## Th17.dmso.vs.Th0.dmso.human	SL5252_SL5255::SL5251_SL5254
cat("read expt mat\n")
expt.mat <- read.delim(file=f.nm.info,colClasses = "character")

for(i in 1:nrow(expt.mat)){
  	all.pairs <- strsplit(expt.mat[i,2],"::")[[1]]
	res.list <- list() # here we will keep DEseq results for each pair
  	for(u in 1:length(all.pairs)){
		e.wt <- strsplit(all.pairs[u],"_")[[1]][1]
		e.ko <- strsplit(all.pairs[u],"_")[[1]][2]
  		e.nm <- expt.mat[i,1]
  		e.nm.wt <- strsplit(e.nm,".vs.")[[1]][1]
  		e.nm.ko <- strsplit(e.nm,".vs.")[[1]][2]
  		cat("working on",e.nm,"pair",all.pairs[u],"\n")
		f.nm.wt<- sapply(e.wt,function(i) grep(paste(sep="",i,"\\."),count.files,value=T))
		f.nm.ko<- sapply(e.ko,function(i) grep(paste(sep="",i,"\\."),count.files,value=T))
		is.kd <- as.logical(as.numeric(expt.mat[i,3])) # val here is either 1 or zero converted to T/F
		if(i == 1){
			x <- read.delim(file=paste(sep="",path.input.counts,f.nm.wt[1]),header=T)
			n.row <- dim(x)[1]
			gn.nms <- toupper(as.character(x[,1]))
			gn.nms.2 <- gn.nms[-which(gn.nms %in% feature.rm)]
			s.mat.pval <- matrix(0,nc=nrow(expt.mat),nr=length(gn.nms.2),dimnames=list(gn.nms.2,expt.mat[,1]))
			s.mat.padj <- matrix(0,nc=nrow(expt.mat),nr=length(gn.nms.2),dimnames=list(gn.nms.2,expt.mat[,1]))
			s.mat.log2fc <- matrix(0,nc=nrow(expt.mat),nr=length(gn.nms.2),dimnames=list(gn.nms.2,expt.mat[,1]))
			s.mat.prcnt.chng <- matrix(0,nc=nrow(expt.mat),nr=length(gn.nms.2),dimnames=list(gn.nms.2,expt.mat[,1]))
		}
	  ## get ht experiments for e.wt into a matrix
	  m.wt <- matrix(0,nr=n.row,nc=length(f.nm.wt))
	  rownames(m.wt) <- gn.nms
	  for(j in 1:length(f.nm.wt)){
	    x <- read.delim(file=paste(sep="",path.input.counts,f.nm.wt[j]),header=T)
	    m.wt[,j] <- as.numeric(x[,2])
	  }
	  m.wt <- m.wt[-which(rownames(m.wt) %in%   feature.rm),]
	  ## get ht experiments for e.ko into a matrix
	  m.ko <- matrix(0,nr=n.row,nc=length(f.nm.ko))
	  rownames(m.ko) <- gn.nms
	  for(j in 1:length(f.nm.ko)){
	    x <- read.delim(file=paste(sep="",path.input.counts,f.nm.ko[j]),header=T)
	    m.ko[,j] <- as.numeric(x[,2])
	  }
	  m.ko <- m.ko[-which(rownames(m.ko) %in%   feature.rm),]
	  countData <- cbind(m.wt,m.ko) + pseudo.count
	  colnames(countData) <- c(e.wt,e.ko)
	  conditions <- factor(c(rep(e.nm.wt,length(e.wt)),rep(e.nm.ko,length(e.ko))),levels=c(e.nm.ko,e.nm.wt))
	  cds <- newCountDataSet(countData, conditions, sizeFactors = NULL, phenoData = NULL, featureData=NULL)
	  cds <- estimateSizeFactors( cds )
	  ## if we have no replicates estimate gene's variance from both conditions as biological repeats
	  if(dim(cds)[2]==2){
	    cds <- estimateVarianceFunctions( cds,pool=T)
	  } else {
	    cds <- estimateVarianceFunctions( cds )
	  }
	  res.list[[all.pairs[u]]] <- nbinomTest( cds, levels(conditions)[1],levels(conditions)[2])
	  colnames(res.list[[all.pairs[u]]])[3:4] <- levels(conditions)
	}
	# we will now combine results for all comparison pairs
	c.nms <- colnames(res.list[[all.pairs[1]]]) # col names
	res <- res.list[[all.pairs[1]]]
	for (j in 1:length(c.nms)){
		c.nm <- c.nms[j]
		if(c.nm=="id" | c.nm=="resVarA" | c.nm=="resVarB"){
			next
		} else if (c.nm=="pval" | c.nm=="padj"){
			tmp <- matrix(0,nr=nrow(res),nc=length(all.pairs))
			for(u in 1:length(all.pairs)){
				tmp[,u] <- res.list[[ all.pairs[u] ]][,c.nm]
			}
			################
			# combine pvals using geometric mean (not used)
			# res[,c.nm] <- apply(tmp,1,function(i) prod(i)^(1/length(i)))
			################
			# if more than 1 pval for each gene, combine pvals with fisher method
			if(length(all.pairs)>1){
				w.chi <- apply(tmp,1,function(i) -2*sum(log(i)) )
				res[,c.nm]  <-  pchisq(w.chi, df=2*ncol(tmp), lower.tail = F)					
			} else {
				res[,c.nm]  <-  tmp					
			}
		} else {
			tmp <- matrix(0,nr=nrow(res),nc=length(all.pairs))
			for(u in 1:length(all.pairs)){
				tmp[,u] <- res.list[[ all.pairs[u] ]][,c.nm]
			}
			res[,c.nm] <- apply(tmp,1,mean)
		}
	}
	###############################
	# in cases where log2 fold change sign was opposite between comparisons it is wrong to combine pvalues
	# filter those out by setting pvalues to 1
	# we can do this for cases where we have two pairs if we have more it is not handled here (our data has two pairs)
	tmp <- matrix(0,nr=nrow(res),nc=length(all.pairs))
	if(length(all.pairs)==2){
		for(u in 1:length(all.pairs)){
			tmp[,u] <- res.list[[ all.pairs[u] ]][,"log2FoldChange"]
		}
		ix.filter.1 <- which(sign(tmp[,1]) != sign(tmp[,2]))
		ix.filter.2 <- which(abs(tmp[,1])>0.2 & abs(tmp[,2]) > 0.2)
		ix.filter <- intersect(ix.filter.1,ix.filter.2)
		res[ix.filter,"pval"] <- 1
		res[ix.filter,"padj"] <- 1
	}
	###############################

	###############################
	# in cases where log2 fold change sign was not opposite between comparisons it is wrong to average pvalues
	# filter those out by setting pvalues to 1
	# we can do this for cases where we have two pairs if we have more it is not handled here (our data has two pairs)
	# for now this is out
	# tmp <- matrix(0,nr=nrow(res),nc=length(all.pairs))
	# if(length(all.pairs)==2){
	# 	for(u in 1:length(all.pairs)){
	# 		tmp[,u] <- res.list[[ all.pairs[u] ]][,"log2FoldChange"]
	# 	}
	# 	ix.filter <- which(sign(tmp[,1]) != sign(tmp[,2]))
	# 	res[ix.filter,"pval"] <- 1
	# 	res[ix.filter,"padj"] <- 1
	# }
	###############################
  ################### FIND genes with low expression in wt and KO ######################
	  e.wt <- strsplit(all.pairs,"_")[[1]]
	  e.ko <- strsplit(all.pairs,"_")[[1]]
	  # get fpkm files from server (bot)
	  f.nm.wt<- paste(sep="",e.wt,"_genes.expr")
	  cat("get rpkm for expt:",e.nm.wt,"SL numbers:",e.wt,"\n")
	  for(j in 1:length(f.nm.wt)){
		cmd.line <- paste(sep="","scp am2654@bot.bio.nyu.edu:",path.input.fpkm,e.wt[j],"/cufflinks_out/",f.nm.wt[j], " tmp/")
		system(cmd.line)
	  }
	  # read fpkm files from local (tmp/)
	  for(j in 1:length(f.nm.wt)){
		# fields.type.list <- list(gene_id=character(),bundle_id=numeric(),chr=character(),left=numeric(),right=numeric(),
		# FPKM=numeric(),FPKM_conf_lo=numeric(),FPKM_conf_hi=numeric(),status=character())
		# w=as.data.frame(scan(file=paste(sep="","tmp/",f.nm.wt[j]),sep="\t",what=fields.type.list,skip = 1 ))
		tmp <- as.matrix(read.delim(paste(sep="","tmp/",f.nm.wt[j]),sep="\t"))
		if(j==1){
		  fpkm.wt <- matrix(0,nr=length(unique(tmp[,"gene_id"])),nc=length(f.nm.wt) )
		  rownames(fpkm.wt) <- unique(tmp[,"gene_id"])
		}
		tmp.non.unique <- table(tmp[,1])
		ix.non.unique <- which(tmp.non.unique>1)
		gns.unique <- names(which(tmp.non.unique==1))
		ix.tmp <- which(tmp[,"gene_id"] %in% gns.unique)
	  	fpkm.wt[tmp[ix.tmp,"gene_id"],j] <- as.numeric(tmp[ix.tmp,"FPKM"])
	  	for(k in 1:length(ix.non.unique)){
		gn.id <- names(ix.non.unique[k])
		ix <- which(tmp[,"gene_id"]==gn.id)
		fpkm.wt[gn.id,j] <- max(as.numeric(tmp[ix,"FPKM"]))
	  	}
	  }
	
	  f.nm.ko<- paste(sep="",e.ko,"_genes.expr")
	  cat("get rpkm for expt:",e.nm.ko,"SL numbers:",e.ko,"\n")
	  for(j in 1:length(f.nm.ko)){
	cmd.line <- paste(sep="","scp am2654@bot.bio.nyu.edu:",path.input.fpkm,e.ko[j],"/cufflinks_out/",f.nm.ko[j], " tmp/")
	system(cmd.line)
	  }
	
	  for(j in 1:length(f.nm.ko)){
	tmp <- as.matrix(read.delim(paste(sep="","tmp/",f.nm.ko[j]),sep="\t"))
	if(j==1){
	  fpkm.ko <- matrix(0,nr=length(unique(tmp[,"gene_id"])),nc=length(f.nm.ko) )
	  rownames(fpkm.ko) <- unique(tmp[,"gene_id"])
	}		
	# tmp.non.unique <- sort(table(tmp[,1]),decreasing=T)
	tmp.non.unique <- table(tmp[,1])
	ix.non.unique <- which(tmp.non.unique>1)
	# ix.unique <- which(tmp.non.unique==1)
	gns.unique <- names(which(tmp.non.unique==1))
	ix.tmp <- which(tmp[,"gene_id"] %in% gns.unique)
	  	fpkm.ko[tmp[ix.tmp,"gene_id"],j] <- as.numeric(tmp[ix.tmp,"FPKM"])
	  	for(k in 1:length(ix.non.unique)){
		gn.id <- names(ix.non.unique[k])
		ix <- which(tmp[,"gene_id"]==gn.id)
		fpkm.ko[gn.id,j] <- max(as.numeric(tmp[ix,"FPKM"]))
	  	}
	  }
	
	  rownames(fpkm.wt) <- toupper(rownames(fpkm.wt))
	  rownames(fpkm.ko) <- toupper(rownames(fpkm.ko))
	  fpkm.wt <- apply(fpkm.wt,1,mean)
	  fpkm.ko <- apply(fpkm.ko,1,mean)

  # find genes that are not expressed by more than fc.cut rpkm in th0,th17, or ko condition of DEseq comparison
  gns.low.ko <- names(which((fpkm.ko < fpkm.cut)))
  gns.low.th0 <- names(which(th0.mean < fpkm.cut))
  gns.low.th17 <- names(which(th17.mean < fpkm.cut))
  gns.low.expressed <- intersect(intersect(gns.low.th17,gns.low.th0),gns.low.ko)
  ###################### END:FIND genes with low expression in wt and KO ######################
  
  ###################### START:find genes with low FC btwn wt and KO ######################
	#   if(is.kd==TRUE){
	# fc.cut <- fc.cut.kd
	#   } else {
	# fc.cut <- fc.cut.ko
	#   }
	# 
	prcnt.change <- abs(res[,4]-res[,3])/res[,4]*100 # col 4 is wt, col 3 is ko
	#   ix.low.fc <- which(prcnt.change<=fc.cut)
	#   res[ix.low.fc,c("pval","padj")] <- 1
  ###################### END:find genes with low FC btwn wt and KO ######################

  ix.low.expressed <- which(res[,"id"] %in% gns.low.expressed)
  res[ix.low.expressed,c("pval","padj")] <- 1

  # res$mean.rpkm.wt <- res$mean.rpkm.ko <- rep(0,length(res$id))
  res$mean.rpkm.ko <- fpkm.ko[res$id]
  res$mean.rpkm.wt <- fpkm.wt[res$id]
  # also if no fpkm value was found remove (NAs)
  ix <- which(is.na(res[,"mean.rpkm.wt"]))
  res[ix,c("pval","padj")] <- 1
  # res[ix.low.expressed,c("pval","padj")] <- 1
  gns.with.rpkm <- res$id[which(res$id %in% gns)]
  res$mean.rpkm.th17 <- res$mean.rpkm.th0 <- rep(0,length(res$id))
  res$mean.rpkm.th17[which(res$id %in% gns.with.rpkm)] <- th17.mean[gns.with.rpkm]
  res$mean.rpkm.th0[which(res$id %in% gns.with.rpkm)] <- th0.mean[gns.with.rpkm]
  res$prcnt.chng <- prcnt.change
  s.mat.pval[,i] <- res$pval
  s.mat.padj[,i] <- res$padj
  s.mat.log2fc[,i] <- res$log2FoldChange
  s.mat.prcnt.chng[,i] <- res$prcnt.chng
  write.table(res,file=paste(path.results,e.nm,"_",date.is,".xls",sep=""),sep="\t",row.names=FALSE)
}

## here we 'multiply' (element wise, A_i_j times B_i_j for all i and j) the pval matrix by the sign of the log2 fold change matrix
## this step allows us to view only the pvalue and say if we have down regulation or up regulation

# this matrix will be used for ChIP scores under combine data script
# path.nm <- paste(sep="",path.input,"activation/")

if(! (date.is %in% list.files(path.input.deseq))){
	system(paste(sep="","mkdir ", path.input.deseq,date.is,"/"))			
}

path.input.dated <- paste(sep="", path.input.deseq,date.is,"/")
s.mat.pval.signed <- -log10(s.mat.pval) * sign(s.mat.log2fc)
write.table(s.mat.pval.signed,file=paste(path.input.dated,"DEseq_pval_signed_",date.is,".xls",sep=""),sep="\t")
write.table(s.mat.log2fc,file=paste(path.input.dated,"DEseq_log2fc_",date.is,".xls",sep=""),sep="\t")
write.table(s.mat.prcnt.chng,file=paste(path.input.dated,"DEseq_prcnt_chng_",date.is,".xls",sep=""),sep="\t")
## other results...
write.table(s.mat.pval.signed,file=paste(path.results,"summary.pval.signed.xls",sep=""),sep="\t")
write.table(s.mat.pval,file=paste(path.results,"summary.pval.xls",sep=""),sep="\t")
write.table(s.mat.padj,file=paste(path.results,"summary.pval.adjusted.xls",sep=""),sep="\t")
write.table(s.mat.log2fc,file=paste(path.results,"summary.log2fc.xls",sep=""),sep="\t")
write.table(s.mat.prcnt.chng,file=paste(path.results,"summary.prcnt.chng.xls",sep=""),sep="\t")

n <- ncol(s.mat.pval.signed)
ix.invivo <- grep("IL17a.gfp.plusve.SI.vs.IL17a.gfp.minusve.SI",colnames(s.mat.pval.signed))
fc.invivo <-  s.mat.log2fc[,ix.invivo]
pval.invivo <-  s.mat.pval.signed[,ix.invivo]
ix <- (n-2):n
s.mat.pval.signed.small <- s.mat.pval.signed[,ix]
s.mat.log2fc.small <- s.mat.log2fc[,ix]

average.specificity <- apply(s.mat.pval.signed.small,1,mean)
sum.specificity <- apply(s.mat.pval.signed.small,1,sum)
max.specificity <- apply(abs(s.mat.pval.signed.small),1,max)*sign(apply(s.mat.pval.signed.small,1,max))
min.specificity <- apply(abs(s.mat.pval.signed.small),1,min)*sign(apply(s.mat.pval.signed.small,1,min))
s.mat.pval.signed.small <- cbind(s.mat.log2fc.small,s.mat.pval.signed.small,fc.invivo,pval.invivo,
	average.specificity,sum.specificity,max.specificity,min.specificity)
x <- colnames(s.mat.pval.signed.small)
colnames(s.mat.pval.signed.small)[1:3] <- paste(sep="","fc.",x[1:3])
colnames(s.mat.pval.signed.small)[4:6] <- paste(sep="","pval.",x[4:6])
s.mat.pval.signed.small <- s.mat.pval.signed.small[order(abs(s.mat.pval.signed.small[,"min.specificity"]),decreasing=T),]
write.table(s.mat.pval.signed.small,file=paste(path.input.dated,"specificity_mat_",date.is,".xls",sep=""),sep="\t")
write.table(s.mat.pval.signed.small,file=paste(path.results,"specificity_mat_",date.is,".xls",sep=""),sep="\t")


